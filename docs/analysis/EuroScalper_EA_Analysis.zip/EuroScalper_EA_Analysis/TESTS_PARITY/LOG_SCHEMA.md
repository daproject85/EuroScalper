
# Canonical Log Schema (for parity testing)

Columns:
- ts
- symbol
- magic
- event        # entry_open / add / tp_sync / close_all / equity_stop / hidden_tp / daily_target
- side         # buy/sell/-
- lots
- price
- last_entry_price
- avg_price
- tp_price
- floating_pl
- daily_closed_pl
- notes
