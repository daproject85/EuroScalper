
# Trace: First Entry BUY
- t0: session_ok, Close[1] >= Close[2]
- compute lot I_d_44; I_i_98 mode → lots I_d_69
- f0_15(0, I_d_69, Ask, slippage, ...)
- recompute avg I_d_48; TP I_d_80 = avg + TP*_Point; OrderModify for each order
